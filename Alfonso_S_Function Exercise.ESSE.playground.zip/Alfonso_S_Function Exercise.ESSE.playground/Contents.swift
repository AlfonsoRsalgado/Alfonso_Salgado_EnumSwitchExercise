enum sandwich: CaseIterable {
    case bread, mayo, onion, tomato, lettice, cheese, chicken, bread2
}

let Sandwichingrients = sandwich.allCases.count
print ("the sandwich contains -> \(Sandwichingrients) ingrients")

for sandwichingredients in sandwich.allCases {
    print(sandwichingredients)
}
